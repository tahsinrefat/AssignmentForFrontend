import './App.css'
import NavBar from './components/NavBar'
import Introduction from './components/Introduction'
import AboutMe from './components/AboutMe'
import Services from './components/Services'
import MyProject from './components/MyProject'
import ContactMe from './components/ContactMe'
import Testimonials from './components/Testimonials'
import Footer from './components/Footer'

function App() {

  return (
    <>
      <NavBar />
      <Introduction />
      <AboutMe />
      <Services />
      <MyProject />
      <Testimonials />
      <ContactMe />
      <Footer />
    </>
  )
}

export default App
