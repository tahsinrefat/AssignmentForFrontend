import React from 'react'
import Cards from './Cards'

const Services = () => {
  const cardContents = [
    {
      imageUrl: "src/assets/UiImage.png",
      title: "UI/UX",
      description: "Lorem ipsum dolor sit amet consectetur. Morbi diam nisi nam diam interdum"
    },
    {
      imageUrl: "src/assets/WebImage.png",
      title: "Website Design",
      description: "Lorem ipsum dolor sit amet consectetur. Morbi diam nisi nam diam interdum"
    },
    {
      imageUrl: "src/assets/AppImage.png",
      title: "App Design",
      description: "Lorem ipsum dolor sit amet consectetur. Morbi diam nisi nam diam interdum"
    },
    {
      imageUrl: "src/assets/GraphicImage.png",
      title: "Graphic Design",
      description: "Lorem ipsum dolor sit amet consectetur. Morbi diam nisi nam diam interdum"
    }
  ];
  return (
    <div className="services" id='services'>
        <div className="services-text">
            Services
        </div>
        <div className="description">
            Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium
        </div>
        <div className="cards">
          {
            cardContents.map((content, index) => (
              <Cards key={index} content={content} />
            ))
          }
            {/* <Cards />
            <Cards />
            <Cards />
            <Cards /> */}
        </div>
    </div>
  )
}

export default Services