import React from 'react'

const Cards = ( {content} ) => {

  const { imageUrl, title, description } = content;
  return (
    <div className="card">
        <div className="image" style={{ backgroundImage: `url(${imageUrl})`}}></div>
        <div className="title">{ title }</div>
        <div className="description">
            { description }
        </div>
    </div>
  )
}

export default Cards