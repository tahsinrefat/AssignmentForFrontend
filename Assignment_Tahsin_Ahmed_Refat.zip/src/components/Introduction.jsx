import React from 'react'

const Introduction = () => {
  return (
    <div className="intro" id='introduction'>
        <div className="text">
            <div className="hi">
                Hi I am
            </div>
            <div className="name">
                Muhammad Umair
            </div>
            <div className="designer">
                <div className="left-text">UI & UX</div>
                <div className="right-text">Designer</div>
            </div>
            <div className="description">
                Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium. Turpis tempus pharetra
            </div>
            <div className="hire-btn">
                Hire Me
            </div>
        </div>

        <div className="image-logos">
            <div className="image">
                <div className="image-container"></div>
            </div>
            <div className="logos">
                <div className="logo">
                    <svg fill="#000000" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2.04C6.5 2.04 2 6.53 2 12.06C2 17.06 5.66 21.21 10.44 21.96V14.96H7.9V12.06H10.44V9.85C10.44 7.34 11.93 5.96 14.22 5.96C15.31 5.96 16.45 6.15 16.45 6.15V8.62H15.19C13.95 8.62 13.56 9.39 13.56 10.18V12.06H16.34L15.89 14.96H13.56V21.96C15.92 21.59 18.06 20.39 19.61 18.57C21.16 16.75 22.01 14.45 22 12.06C22 6.53 17.5 2.04 12 2.04Z"></path>
                    </svg>
                </div>
                <div className="logo">
                    <svg viewBox="0 -2 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="#000000">
                        <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
                        <g id="SVGRepo_tracerCarrier" strokeLinecap="round" strokeLinejoin="round"></g>
                        <g id="SVGRepo_iconCarrier">
                            <title>twitter [#154]</title>
                            <desc>Created with Sketch.</desc>
                            <defs> </defs>
                            <g id="Page-1" stroke="none" fill="none" fillRule="evenodd">
                            <g id="Dribbble-Light-Preview" transform="translate(-60.000000, -7521.000000)" fill="#000000">
                                <g id="icons" transform="translate(56.000000, 160.000000)">
                                <path d="M10.29,7377 C17.837,7377 21.965,7370.84365 21.965,7365.50546 C21.965,7365.33021 21.965,7365.15595 21.953,7364.98267 C22.756,7364.41163 23.449,7363.70276 24,7362.8915 C23.252,7363.21837 22.457,7363.433 21.644,7363.52751 C22.5,7363.02244 23.141,7362.2289 23.448,7361.2926 C22.642,7361.76321 21.761,7362.095 20.842,7362.27321 C19.288,7360.64674 16.689,7360.56798 15.036,7362.09796 C13.971,7363.08447 13.518,7364.55538 13.849,7365.95835 C10.55,7365.79492 7.476,7364.261 5.392,7361.73762 C4.303,7363.58363 4.86,7365.94457 6.663,7367.12996 C6.01,7367.11125 5.371,7366.93797 4.8,7366.62489 L4.8,7366.67608 C4.801,7368.5989 6.178,7370.2549 8.092,7370.63591 C7.488,7370.79836 6.854,7370.82199 6.24,7370.70483 C6.777,7372.35099 8.318,7373.47829 10.073,7373.51078 C8.62,7374.63513 6.825,7375.24554 4.977,7375.24358 C4.651,7375.24259 4.325,7375.22388 4,7375.18549 C5.877,7376.37088 8.06,7377 10.29,7376.99705" id="twitter-[#154]"> </path>
                                </g>
                            </g>
                            </g>
                        </g>
                    </svg>
                </div>
                <div className="logo">
                    <svg viewBox="0 0 192 192" xmlns="http://www.w3.org/2000/svg" fill="none"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path stroke="#000000" stroke-width="12" d="M96 162c-14.152 0-24.336-.007-32.276-.777-7.849-.761-12.87-2.223-16.877-4.741a36 36 0 0 1-11.33-11.329c-2.517-4.007-3.98-9.028-4.74-16.877C30.007 120.336 30 110.152 30 96c0-14.152.007-24.336.777-32.276.76-7.849 2.223-12.87 4.74-16.877a36 36 0 0 1 11.33-11.33c4.007-2.517 9.028-3.98 16.877-4.74C71.663 30.007 81.847 30 96 30c14.152 0 24.336.007 32.276.777 7.849.76 12.87 2.223 16.877 4.74a36 36 0 0 1 11.329 11.33c2.518 4.007 3.98 9.028 4.741 16.877.77 7.94.777 18.124.777 32.276 0 14.152-.007 24.336-.777 32.276-.761 7.849-2.223 12.87-4.741 16.877a36 36 0 0 1-11.329 11.329c-4.007 2.518-9.028 3.98-16.877 4.741-7.94.77-18.124.777-32.276.777Z"></path><circle cx="96" cy="96" r="30" stroke="#000000" stroke-width="12"></circle><circle cx="135" cy="57" r="9" fill="#000000"></circle></g></svg>                </div>
                <div className="logo">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18.72 4H5.37C5.2 4 5.03 4.02 4.86 4.08C4.7 4.13 4.55 4.22 4.43 4.34C4.3 4.46 4.2 4.6 4.12 4.75C4.05 4.91 4.01 5.08 4 5.25V18.63C4.01 18.99 4.16 19.33 4.41 19.59C4.67 19.84 5.01 19.99 5.37 20H18.72C19.07 19.98 19.4 19.83 19.64 19.58C19.88 19.32 20.01 18.98 20 18.63V5.25C20 5.08 19.97 4.92 19.91 4.76C19.84 4.61 19.75 4.47 19.63 4.35C19.51 4.23 19.37 4.14 19.21 4.08C19.05 4.02 18.89 4 18.72 4ZM9 17.34H6.67V10.21H9V17.34ZM7.89 9.13C7.73 9.14 7.57 9.11 7.41 9.05C7.26 9 7.13 8.9 7.01 8.78C6.9 8.67 6.81 8.53 6.75 8.38C6.69 8.22 6.66 8.06 6.67 7.9C6.66 7.74 6.69 7.57 6.75 7.42C6.81 7.27 6.9 7.13 7.02 7.01C7.13 6.89 7.27 6.8 7.43 6.75C7.58 6.69 7.75 6.66 7.91 6.67C8.07 6.66 8.23 6.69 8.39 6.75C8.54 6.81 8.67 6.9 8.79 7.02C8.9 7.13 9 7.27 9.05 7.42C9.11 7.58 9.14 7.74 9.13 7.9C9.14 8.06 9.11 8.23 9.05 8.38C8.99 8.53 8.9 8.67 8.79 8.78C8.67 8.9 8.54 9 8.39 9.05C8.23 9.11 8.07 9.13 7.89 9.13ZM17.34 17.34H15.01V13.73C15.01 12.96 15 11.94 14.03 11.94C13.05 11.94 12.92 12.82 12.92 13.67V17.34H10.58V10.21H12.79V11.07H12.83C13.1 10.57 13.76 10.15 14.66 10.15C16.6 10.15 17.34 11.42 17.34 13.25V17.34Z" fill="#000000"></path>
                    </svg>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Introduction