import React from 'react'

const Testimonials = () => {

  const images = [
    "src/assets/CEO1.png",
    "src/assets/CEO2.png",
    "src/assets/CEO3.png"
  ]

  return (
    <div className="testimonials" id='testimonials'>
      <div className="texts">
        <div className="testimonial-text">
          Testimonials
        </div>
        <div className="description">
          Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium
        </div>
      </div>

      <div className="slider">
        {
          images.map((image, index) => (
            <div key={index} className="item">
            <div className="image" style={{backgroundImage: `url(${image})`}}></div>
            <div className="text">
              <div className="quote">
                <span>"</span>Lorem ipsum dolor sit amet consectetur. In enim cursus odio accumsan. Id leo urna velit neque mattis id tellus arcu condimentum. Augue dictum dolor elementum convallis dignissim malesuada commodo ultrices. <span className='rotate'>"</span>
              </div>
              <div className="name">Name</div>
              <div className="ceo">CEO</div>
            </div>
          </div>
          ))
        }
      </div>
    </div>
  )
}

export default Testimonials;