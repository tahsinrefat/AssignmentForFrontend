import React from 'react'

const NavBar = () => {
  return (
    <nav>
        <div className="logo">
            <div className="logo-pic">
                MU
            </div>
            <div className="logo-text">
                <span>M</span>umair
            </div>
        </div>

        <div className="navs">
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#about-me">About Me</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#my-projects">Projects</a></li>
                <li><a href="#testimonials">Testimonials</a></li>
                <li><a href="#contact-me">Contact</a></li>
                <li className='download'>Dwonload CV</li>
            </ul>
        </div>
    </nav>
  )
}

export default NavBar