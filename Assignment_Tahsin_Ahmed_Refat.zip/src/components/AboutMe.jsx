import React from 'react'
import { useState, useEffect } from "react";

const AboutMe = () => {

    const [progressValues, setProgressValues] = useState({
        ux: 0,
        web: 0,
        app: 0,
        graphic: 0,
      });

      useEffect(() => {
        setTimeout(() => {
          setProgressValues({
            ux: 90,
            web: 75,
            app: 60,
            graphic: 85,
          });
        }, 500);
      }, []);


  return (
    <div className="about-me" id='about-me'>
        <div className="image"></div>
        <div className="text">
            <div className="about-text">
                About Me
            </div>
            <div className="description">
                Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium. Turpis tempus pharetra
            </div>
            <div className="skills">
                <div className="skill">UX</div>
                <div className="progress-bar">
                    <div className="progress-fill" style={ {width: `${progressValues.ux}%`} }>
                        <div className="progress-circle" style={{ left: `${progressValues.ux}%` }}></div>
                    </div>
                </div>

                <div className="skill">Web Design</div>
                <div className="progress-bar">
                    <div className="progress-fill" style={ {width: `${progressValues.web}%`} }>
                        <div className="progress-circle" style={{ left: `${progressValues.web}%` }}></div>
                    </div>
                </div>

                <div className="skill">App Design</div>
                <div className="progress-bar">
                    <div className="progress-fill" style={ {width: `${progressValues.app}%`} }>
                        <div className="progress-circle" style={{ left: `${progressValues.app}%` }}></div>
                    </div>
                </div>

                <div className="skill">Graphic Design</div>
                <div className="progress-bar">
                    <div className="progress-fill" style={ {width: `${progressValues.graphic}%`} }>
                        <div className="progress-circle" style={{ left: `${progressValues.graphic}%` }}></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default AboutMe