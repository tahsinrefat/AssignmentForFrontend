import React from 'react'

const ContactMe = () => {
  return (
    <div className="contact-me" id='contact-me'>
        <div className="title">Lets Design Together</div>
        <dv className="description">
            Lorem ipsum dolor sit amet consectetur. Tristique amet sed massa nibh lectus netus in. Aliquet donec morbi convallis pretium
        </dv>
        <div className="email">
            <div className="input">
                <input type="text" placeholder='Enter Your Email'/>
            </div>
            <div className="button">Contact Me</div>
        </div>
    </div>
  )
}

export default ContactMe