import React, { useState } from 'react'
import ProjectCards from './ProjectCards'

const MyProject = () => {

  const [activeCategory, setActiveCategory] = useState('all')

  const allDesign = [
    {
      imageUrl: "src/assets/Orange.png",
      category: "UI/UX",
      name: "Ecom Web Page Design"
    },
    {
      imageUrl: "src/assets/Blue.png",
      category: "Web Design",
      name: "AirCalling Landing Page Design"
    },
    {
      imageUrl: "src/assets/Green.png",
      category: "App Design",
      name: "Business Landing Page Design"
    }
  ];

  const uiDesign = [
    {
      imageUrl: "src/assets/Orange.png",
      category: "UI/UX",
      name: "Ecom Web Page Design"
    },
    {
      imageUrl: "src/assets/Blue.png",
      category: "UI/UX",
      name: "AirCalling Landing Page Design"
    },
    {
      imageUrl: "src/assets/Green.png",
      category: "UI/UX",
      name: "Business Landing Page Design"
    }
  ];

  const webDesign = [
    {
      imageUrl: "src/assets/Blue.png",
      category: "Web Design",
      name: "AirCalling Landing Page Design"
    },
    {
      imageUrl: "src/assets/Green.png",
      category: "Website Design",
      name: "Business Landing Page Design"
    },
    {
      imageUrl: "src/assets/Orange.png",
      category: "Web Design",
      name: "Ecom Web Page Design"
    }
  ];

  const appDesign = [
    {
      imageUrl: "src/assets/Green.png",
      category: "App Design",
      name: "Business Landing Page Design"
    },
    {
      imageUrl: "src/assets/Blue.png",
      category: "App Design",
      name: "AirCalling Landing Page Design"
    },
    {
      imageUrl: "src/assets/Orange.png",
      category: "App Design",
      name: "Ecom Web Page Design"
    }
  ];

  const graphicDesign = [
    {
      imageUrl: "src/assets/Blue.png",
      category: "Graphic Design",
      name: "AirCalling Landing Page Design"
    },
    {
      imageUrl: "src/assets/Orange.png",
      category: "Graphic Design",
      name: "Ecom Web Page Design"
    },
    {
      imageUrl: "src/assets/Green.png",
      category: "Graphic Design",
      name: "Business Landing Page Design"
    }
  ];

  const getActiveDesign = () => {
    switch (activeCategory) {
      case 'ui':
        return uiDesign;
      case 'web':
        return webDesign;
      case 'app':
        return appDesign;
      case 'graphic':
        return graphicDesign;
      default:
        return allDesign;
    }
  };

  return (
    <div className="projects" id='my-projects'>
        <div className="title">My Projects</div>
        <div className="description">
            Lorem ipsum dolor sit amet consectetur. Mollis erat duis aliquam mauris est risus lectus. Phasellus consequat urna tellus
        </div>
        <div className="buttons">
            <div className={`button ${activeCategory === 'all' ? 'active' : ''}`} onClick={() => setActiveCategory('all')}>All</div>
            <div className={`button ${activeCategory === 'ui' ? 'active' : ''}`} onClick={() => setActiveCategory('ui')}>UI/UX</div>
            <div className={`button ${activeCategory === 'web' ? 'active' : ''}`} onClick={() => setActiveCategory('web')}>Web Design</div>
            <div className={`button ${activeCategory === 'app' ? 'active' : ''}`} onClick={() => setActiveCategory('app')}>App Design</div>
            <div className={`button ${activeCategory === 'graphic' ? 'active' : ''}`} onClick={() => setActiveCategory('graphic')}>Graphic Design</div>
        </div>
        <div className="project-cards">
          {
            getActiveDesign().map(( content, index) => (
              <ProjectCards key={index} content={content} />
            ))
          }
        </div>
    </div>
  )
}

export default MyProject