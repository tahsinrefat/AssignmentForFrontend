import React from 'react'

const ProjectCards = ( {content} ) => {

  const { imageUrl, category, name } = content;

  return (
    <div className="project-card">
        <div className="image" style={{ backgroundImage: `url(${imageUrl})`}}></div>
        <div className="category">{ category}</div>
        <div className="name"> { name } </div>
    </div>
  )
}

export default ProjectCards